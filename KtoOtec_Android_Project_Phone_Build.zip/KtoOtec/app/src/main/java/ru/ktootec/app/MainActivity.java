package ru.ktootec.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.text.InputType;
import android.view.View;
import android.widget.*;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private EditText input;
    private TextView resultTitle, resultValue, resultNote;
    private LinearLayout resultCard;

    private static final int BG = Color.rgb(8, 8, 8);
    private static final int PANEL = Color.rgb(22, 22, 22);
    private static final int MUTED = Color.rgb(145, 145, 145);
    private static final int WHITE = Color.WHITE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(26), dp(48), dp(26), dp(32));
        scroll.addView(page);

        TextView brand = new TextView(this);
        brand.setText("КтоОтец");
        brand.setTextColor(WHITE);
        brand.setTextSize(30);
        brand.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        brand.setGravity(Gravity.CENTER);
        page.addView(brand, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Узнай имя по отчеству");
        subtitle.setTextColor(MUTED);
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = matchWrap();
        subParams.topMargin = dp(10);
        page.addView(subtitle, subParams);

        TextView label = new TextView(this);
        label.setText("ОТЧЕСТВО");
        label.setTextColor(MUTED);
        label.setTextSize(11);
        label.setLetterSpacing(0.12f);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams labelParams = matchWrap();
        labelParams.topMargin = dp(58);
        page.addView(label, labelParams);

        input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(18);
        input.setTextColor(WHITE);
        input.setHintTextColor(Color.rgb(105, 105, 105));
        input.setHint("Например, Александрович");
        input.setPadding(dp(17), 0, dp(17), 0);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setBackground(rounded(PANEL, 14, Color.rgb(48,48,48), 1));
        LinearLayout.LayoutParams inputParams = matchWrap();
        inputParams.height = dp(58);
        inputParams.topMargin = dp(13);
        page.addView(input, inputParams);

        Button button = new Button(this);
        button.setText("ОПРЕДЕЛИТЬ");
        button.setTextColor(Color.BLACK);
        button.setTextSize(13);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);
        button.setBackground(rounded(WHITE, 14, WHITE, 0));
        LinearLayout.LayoutParams btnParams = matchWrap();
        btnParams.height = dp(56);
        btnParams.topMargin = dp(14);
        page.addView(button, btnParams);
        button.setOnClickListener(v -> determine());

        resultCard = new LinearLayout(this);
        resultCard.setOrientation(LinearLayout.VERTICAL);
        resultCard.setGravity(Gravity.CENTER);
        resultCard.setPadding(dp(18), dp(22), dp(18), dp(22));
        resultCard.setBackground(rounded(PANEL, 16, Color.rgb(42,42,42), 1));
        LinearLayout.LayoutParams cardParams = matchWrap();
        cardParams.topMargin = dp(28);
        page.addView(resultCard, cardParams);

        resultTitle = new TextView(this);
        resultTitle.setText("Предполагаемое имя отца");
        resultTitle.setTextColor(MUTED);
        resultTitle.setTextSize(13);
        resultTitle.setGravity(Gravity.CENTER);
        resultCard.addView(resultTitle, matchWrap());

        resultValue = new TextView(this);
        resultValue.setTextColor(WHITE);
        resultValue.setTextSize(28);
        resultValue.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        resultValue.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams valueParams = matchWrap();
        valueParams.topMargin = dp(9);
        resultCard.addView(resultValue, valueParams);

        resultNote = new TextView(this);
        resultNote.setTextColor(MUTED);
        resultNote.setTextSize(12);
        resultNote.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteParams = matchWrap();
        noteParams.topMargin = dp(12);
        resultCard.addView(resultNote, noteParams);
        resultCard.setVisibility(View.GONE);

        TextView footer = new TextView(this);
        footer.setText("Результат основан на правилах образования отчеств");
        footer.setTextColor(Color.rgb(95,95,95));
        footer.setTextSize(11);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footParams = matchWrap();
        footParams.topMargin = dp(34);
        page.addView(footer, footParams);

        setContentView(scroll);
    }

    private void determine() {
        String raw = input.getText().toString().trim().toLowerCase(new Locale("ru"));
        raw = raw.replace("ё", "е").replaceAll("[^а-я]", "");
        if (raw.isEmpty()) {
            input.setError("Введите отчество");
            return;
        }

        String father = knownNames().get(raw);
        String note = "Имя определено по распространённой форме отчества.";
        if (father == null) {
            father = inferName(raw);
            if (father == null) {
                resultCard.setVisibility(View.GONE);
                input.setError("Не удалось распознать отчество");
                return;
            }
            note = "Предположение по окончанию отчества. Возможны исключения.";
        }

        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(input.getWindowToken(), 0);
        resultValue.setText(capitalize(father));
        resultNote.setText(note);
        resultCard.setVisibility(View.VISIBLE);
    }

    private String inferName(String p) {
        // Common Russian patronymic patterns. Some names are irregular, so common
        // forms are handled explicitly in knownNames().
        String[] endings = {"ович", "евич", "ич", "овна", "евна", "ична", "инична"};
        String[] replacements = {"ов", "ев", "", "ова", "ева", "а", "а"};
        for (int i = 0; i < endings.length; i++) {
            if (p.endsWith(endings[i]) && p.length() > endings[i].length()) {
                String stem = p.substring(0, p.length() - endings[i].length());
                String candidate = stem + replacements[i];
                if (candidate.length() >= 2) return candidate;
            }
        }
        return null;
    }

    private Map<String, String> knownNames() {
        Map<String, String> m = new HashMap<>();
        add(m, "александрович александровна", "александр");
        add(m, "дмитриевич дмитриевна", "дмитрий");
        add(m, "сергеевич сергеевна", "сергей");
        add(m, "андреевич андреевна", "андрей");
        add(m, "максимович максимовна", "максим");
        add(m, "иванович ивановна", "иван");
        add(m, "михайлович михайловна", "михаил");
        add(m, "владимирович владимировна", "владимир");
        add(m, "николаевич николаевна", "николай");
        add(m, "алексеевич алексеевна", "алексей");
        add(m, "евгеньевич евгеньевна", "евгений");
        add(m, "павлович павловна", "павел");
        add(m, "романович романовна", "роман");
        add(m, "артемович артемовна", "артем");
        add(m, "кириллович кирилловна", "кирилл");
        add(m, "ильич ильинична", "илья");
        add(m, "кузьмич кузьминична", "кузьма");
        add(m, "фомич фоминична", "фома");
        add(m, "саввич саввична", "савва");
        add(m, "никитич никитична", "никита");
        add(m, "лукич лукинична", "лука");
        add(m, "данилович даниловна", "данил");
        add(m, "яковлевич яковлевна", "яков");
        add(m, "григорьевич григорьевна", "григорий");
        add(m, "борисович борисовна", "борис");
        add(m, "викторович викторовна", "виктор");
        add(m, "олегович олеговна", "олег");
        add(m, "эдуардович эдуардовна", "эдуард");
        add(m, "станиславович станиславовна", "станислав");
        add(m, "вячеславович вячеславовна", "вячеслав");
        add(m, "ярославович ярославовна", "ярослав");
        add(m, "тимурович тимуровна", "тимур");
        add(m, "денисович денисовна", "денис");
        add(m, "антонович антоновна", "антон");
        add(m, "геннадьевич геннадьевна", "геннадий");
        add(m, "валерьевич валерьевна", "валерий");
        add(m, "юрьевич юрьевна", "юрий");
        add(m, "игоревич игоревна", "игорь");
        return m;
    }

    private void add(Map<String, String> map, String forms, String name) {
        for (String form : forms.split(" ")) map.put(form, name);
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0,1).toUpperCase(new Locale("ru")) + s.substring(1);
    }

    private GradientDrawable rounded(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeWidth > 0) d.setStroke(dp(strokeWidth), strokeColor);
        return d;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
